import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox
import time
import re
import os

class VoterLookupApp:
    def __init__(self, master, df, eck_data):
        self.master = master
        master.title("Voter Information Query System")
        master.geometry("1200x800")
        
        self.df = df
        self.eck_data = eck_data
        self.all_attributes = list(df.columns)
        
        # 创建输入和输出框架
        self.input_frame = ttk.LabelFrame(master, text="Input Information", padding=10)
        self.input_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.output_frame = ttk.LabelFrame(master, text="Query Results", padding=10)
        self.output_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # 底部状态栏
        self.status_var = tk.StringVar()
        self.status_bar = ttk.Label(master, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # 创建输入字段
        self.input_vars = {}
        self.create_input_fields()
        
        # 创建输出字段
        self.output_vars = {}
        self.create_output_fields()
        
        # 按钮框架
        self.button_frame = ttk.Frame(self.input_frame)
        self.button_frame.grid(row=100, column=0, columnspan=6, pady=10)
        
        # 查询按钮
        self.search_btn = ttk.Button(self.button_frame, text="Search", command=self.search_voter)
        self.search_btn.pack(side=tk.LEFT, padx=5)
        
        # 清除按钮
        self.clear_btn = ttk.Button(self.button_frame, text="Clear", command=self.clear_fields)
        self.clear_btn.pack(side=tk.LEFT, padx=5)
        
        # 初始化状态
        self.status_var.set("Ready - Please enter search criteria")
    
    def create_input_fields(self):
        """创建输入字段"""
        # 收集所有在ECK中出现的属性
        eck_attributes = self.get_all_eck_attributes()
        
        # 创建输入框
        row = 0
        col = 0
        for i, attr in enumerate(eck_attributes):
            # 每行3列
            if i % 3 == 0 and i > 0:
                row += 1
                col = 0
            
            # 标签
            lbl = ttk.Label(self.input_frame, text=f"{attr}:")
            lbl.grid(row=row, column=col*2, padx=5, pady=5, sticky=tk.E)
            
            # 输入框
            var = tk.StringVar()
            entry = ttk.Entry(self.input_frame, textvariable=var, width=20)
            entry.grid(row=row, column=col*2+1, padx=5, pady=5, sticky=tk.W)
            
            self.input_vars[attr] = var
            col += 1
    
    def get_all_eck_attributes(self):
        """从ECK数据中提取所有唯一属性"""
        attributes = set()
        for category, eck_list in self.eck_data.items():
            for eck in eck_list:
                attributes.update(eck[0])  # 嵌入集属性
                attributes.update(eck[1])  # 键属性
        return sorted(attributes)
    
    def create_output_fields(self):
        """创建输出字段"""
        # 使用滚动条
        self.canvas = tk.Canvas(self.output_frame)
        self.scrollbar = ttk.Scrollbar(self.output_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # 创建输出字段
        row = 0
        col = 0
        for i, attr in enumerate(self.all_attributes):
            # 每行3列
            if i % 3 == 0 and i > 0:
                row += 1
                col = 0
            
            # 标签
            lbl = ttk.Label(self.scrollable_frame, text=f"{attr}:")
            lbl.grid(row=row, column=col*2, padx=5, pady=5, sticky=tk.E)
            
            # 输出框（只读）
            var = tk.StringVar()
            entry = ttk.Entry(self.scrollable_frame, textvariable=var, state="readonly", width=40)
            entry.grid(row=row, column=col*2+1, padx=5, pady=5, sticky=tk.W+tk.E)
            
            self.output_vars[attr] = var
            col += 1
    
    def clear_fields(self):
        """清除所有输入和输出字段"""
        for var in self.input_vars.values():
            var.set("")
        
        for var in self.output_vars.values():
            var.set("")
        
        self.status_var.set("All fields cleared")
    
    def search_voter(self):
        """使用ECK查询选民信息"""
        start_time = time.time()
        
        # 清除之前的输出
        for var in self.output_vars.values():
            var.set("")
        
        # 收集用户输入的查询条件
        query_conditions = {}
        for attr, var in self.input_vars.items():
            value = var.get().strip()
            if value:
                # 转换为大写以匹配数据
                query_conditions[attr] = value.upper()
        
        # 检查是否有输入
        if not query_conditions:
            messagebox.showwarning("Input Error", "Please enter at least one search criterion.")
            self.status_var.set("Error: No search criteria entered.")
            return
        
        # 查找匹配的ECK
        matched_eck = None
        matched_category = None
        
        # 按类别优先级搜索
        categories = ["Core Identity", "Address Location", "Contact Information", "Election Information"]
        for category in categories:
            if category in self.eck_data:
                for eck in self.eck_data[category]:
                    E, K = eck
                    # 检查用户输入是否包含当前ECK的嵌入集
                    if E.issubset(set(query_conditions.keys())):
                        matched_eck = eck
                        matched_category = category
                        break
                if matched_eck:
                    break
        
        if not matched_eck:
            messagebox.showwarning("Search Error", "No matching embedded set found. Please provide more information.")
            self.status_var.set("Error: No matching embedded set found.")
            return
        
        # 使用ECK进行查询
        E, K = matched_eck
        self.status_var.set(f"Using ECK of category {matched_category}: Embedding Set={E}, Key Set={K}.")
        
        # 在数据集中查找匹配的记录
        result = self.df.copy()
        
        # 使用键集属性过滤 - 精确匹配
        for key_attr in K:
            if key_attr in query_conditions:
                value = query_conditions[key_attr]
                # 确保列是字符串类型
                result[key_attr] = result[key_attr].astype(str)
                # 精确匹配（区分大小写）
                result = result[result[key_attr] == value]
        
        if result.empty:
            messagebox.showinfo("Query Results", "No matching voter records found.")
            self.status_var.set(f"{self.status_var.get()} | No matching records found.")
            return
        
        # 显示第一条匹配记录
        record = result.iloc[0]
        for attr, var in self.output_vars.items():
            if attr in record:
                # 处理NaN值
                value = record[attr]
                if pd.isna(value):
                    var.set("")
                else:
                    var.set(str(value))
        
        # 更新滚动区域
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        
        # 显示查询时间
        elapsed = time.time() - start_time
        self.status_var.set(f"{self.status_var.get()} | Query time: {elapsed:.3f} seconds | Records found: {len(result)}.")
        
        # 自动滚动到顶部
        self.canvas.yview_moveto(0)

def parse_eck_file(filename):
    """解析ECK文本文件"""
    eck_data = {}
    
    # 如果文件不存在，返回空字典
    if not os.path.exists(filename):
        print("no data!!!")
        return eck_data
    
    with open(filename, 'r', encoding='utf-8') as file:
        content = file.read()
    
    # 使用正则表达式解析类别和ECK
    category_pattern = r"处理类别: (.+?)\n候选嵌入集.+?发现 (\d+) 个嵌入式候选键.+?嵌入式候选键列表:(.+?)(?=\n\n|$)"
    eck_pattern = r"\d+\. 嵌入集: \[(.*?)\]\n   键属性: \[(.*?)\]\n"
    
    # 查找所有类别
    for match in re.finditer(category_pattern, content, re.DOTALL):
        category = match.group(1).strip()
        eck_list = []
        
        # 查找该类别下的所有ECK
        for eck_match in re.finditer(eck_pattern, match.group(3)):
            e_set = set(attr.strip().strip("'") for attr in eck_match.group(1).split(",") if attr.strip())
            k_set = set(attr.strip().strip("'") for attr in eck_match.group(2).split(",") if attr.strip())
            eck_list.append((e_set, k_set))
        
        eck_data[category] = eck_list
    
    return eck_data


def main():
    # 创建示例DataFrame
    df = pd.read_excel("ceshi2.xlsx")
    
    # 清理数据：填充空值并标准化字符串
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = df[col].fillna('').str.strip().str.upper()
    
    # 清理数据：填充空值并标准化字符串
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = df[col].fillna('').astype(str).str.strip().str.upper()
    
    # 解析ECK文件
    eck_filename = "eck.txt"
    eck_data = parse_eck_file(eck_filename)
    
    # 创建GUI应用
    root = tk.Tk()
    app = VoterLookupApp(root, df, eck_data)
    root.mainloop()

if __name__ == "__main__":
    main()
